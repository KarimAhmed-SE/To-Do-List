const express = require("express");
const bodyParser = require("body-parser");
const https = require("https");
const date = require(__dirname + "/date.js");
const mongoose = require("mongoose");
const _ = require("lodash");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

app.set("view engine", "ejs");

mongoose.connect("mongodb+srv://admin:<password>@cluster0.cmtuwi0.mongodb.net/todolistDB");

const itemsSchema = {
  name: String,
};

const Item = mongoose.model("Item", itemsSchema);

const item1 = new Item({
  name: "Fruits",
});

const item2 = new Item({
  name: "Work",
});

const item3 = new Item({
  name: "Gym",
});

const item4 = new Item({
  name: "Hello",
});

const defaultItems = [item1, item2, item3];

const listSchema = {
  name: String,
  items: [itemsSchema],
};

const List = mongoose.model("List", listSchema);

console.log(Item.find({}));

app.get("/", async function (req, res) {
  var day = date.getDate();

  if ((await Item.find({})).length === 0) {
    Item.insertMany(defaultItems).then((err) => {
      if (err) {
        console.log(err);
      } else {
        console.log("Successfully ran the code");
      }
    });

    res.redirect("/");
  } else {
    res.render("list", { listTitle: "Today", newItem: await Item.find({}) });
  }
});

app.get("/:customListName", async function (req, res) {
  const customListName = _.capitalize(req.params.customListName);

  const foundItems = await List.findOne({ name: customListName });

  if (foundItems === null) {
    const list = new List({
      name: customListName,
      items: defaultItems,
    });
    list.save();

    res.redirect("/" + customListName);
  } else {
    console.log("Exists!");
    const shownItems = foundItems.items;
    const shownTitle = foundItems.name;
    res.render("list", {
      listTitle: shownTitle,
      newItem: shownItems,
    });
  }
});

app.get("/about", (req, res) => {
  res.render("about");
});

app.post("/", async (req, res) => {
  const data = req.body.newItemText;
  const listName = req.body.list;

  const item = new Item({
    name: data,
  });
  console.log(req.body);

  if (listName === "Today") {
    Item.create(item).then((err) => {
      if (err) {
        console.log(err);
      } else {
        console.log("Added successfully");
      }
    });

    res.redirect("/");
  } else {
    const foundList = await List.findOne({ name: listName });

    foundList.items.push(item);
    foundList.save();
    res.redirect("/" + listName);
  }
});

app.post("/delete", async (req, res) => {
  const checkedItemId = req.body.checkbox;
  const listName = req.body.listName;

  if (listName === "Today") {
    await List.findOneAndUpdate(
      { name: listName },
      { $pull: { items: { _id: checkedItemId } } }
    ).then((err) => {
      if (err) {
        console.log(err);
      } else {
        console.log("Item removed!");
      }

    });

    res.redirect("/");
  } else {
    await List.findOneAndUpdate(
      { name: listName },
      { $pull: { items: { _id: checkedItemId } } }
    ).then((err) => {
      if (err) {
        console.log(err);
      } else {
        console.log("Item removed!");
      }
    });

    res.redirect("/" + listName);
  }
});

app.listen(3000, function () {
  console.log("Server is running on port 3000");
});
